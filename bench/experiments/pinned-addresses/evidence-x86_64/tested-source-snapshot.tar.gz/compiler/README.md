# GHC Core exporter, prototype schema 1

`./compiler/build.sh` builds a dynamically loaded plugin against **GHC 9.14.1** using only packages shipped with GHC. `./compiler/export.sh examples/THC/Fixtures.hs` compiles the Haskell modules with `-O2 -g -dcore-lint` and exports `build/core/THC.Prim.json` and `build/core/THC.Fixtures.json`. GHC still produces native object/interface files in `build/ghc`; this is useful for checking that the same source is valid GHC Haskell. The THC runtime evaluates the exported expression trees.

The plugin appends `CoreDoPluginPass` to `installCoreToDos`. This observes the **optimized Core pipeline's final `ModGuts`, before Tidy/CorePrep/STG**. The ordinary GHC optimization passes run first. This is executable tree export directly from the GHC API; the runtime never parses a Core pretty dump.

This is a deliberately version-pinned experiment, **not** a lossless, stable, general-purpose Core interchange format. It proves the boundary with a controlled executable subset. `sourceCore` retains the module's readable pre-erasure Core for inspection, and binder metadata retains types, demand, strictness, CPR, arity, call arity, occurrence/one-shot information, join arity and inline pragmas. Module rewrite rules are retained as readable metadata. These strings are evidence for the architecture experiment, not a promise that an optimizer can round-trip arbitrary GHC objects. Full structured coercions, rules, unfoldings, dependencies and representation-polymorphic lowering are subsequent work.

## Executable schema

A module object carries `schema`, `ghc`, `module`, `unit`, `boundary`, `bindings`, `constructors`, and top-level `groups`. Top-level and local let bindings have `{id,name,type,lifted,arity,info,rep,expr}`. Top-level exported/external IDs use `unit:Module.occ`; private/local IDs additionally retain the GHC unique and a module namespace. A unique is not stable across recompilations. GHC units are part of identities so equal module names in different packages remain distinct.

Expressions are tagged arrays:

- `['var', id]`
- `['lit', kind, valueAsString]`
- `['prim', primopOccurrenceName]`, e.g. `+#`
- `['con', constructorId, representationArity]`
- `['app', function, [argument...], [liftedBoolean...], knownWhnfBoolean, safeToEvaluateBoolean]`
- `['lam', [{id,name,type,lifted,coercion,info}...], body]`
- `['let', recursiveBoolean, [binding...], body]`
- `['case', scrutinee, binderId, [alternative...]]`
- `['void']`
- `['unsupported', diagnostic]`

A case alternative is `[kind, discriminator, [binderIds...], body]`, with kind `default`/`data`/`lit`. Default discriminators are null, data discriminators are constructor IDs, literal discriminators are `[literalKind,valueAsString]`. Empty cases remain empty; the runtime must force their scrutinee rather than invent a value.

Representation evidence is an optional final object on each expression. Its zero-based position is `var[2]`, `lit[3]`, `app[6]`, `lam[3]`, `let[4]`, `case[4]`, `con[3]`, `prim[2]`, or `void[1]`. Existing positional fields retain their meaning; older schema-1 exports without this object remain valid and require conservative inference. All binder and binding records also carry `rep`. A representation record is:

```json
{"primReps": ["IntRep"], "kind": "long", "evaluated": true}
```

`primReps` comes from `typePrimRep_maybe`, using the same canonical GHC names as constructor `fieldReps`; unresolved representations are null. `kind` is `long`, `address`, `void`, `data`, `closure`, `object`, or `unknown`. `long` requires exactly one supported signed/unsigned integer register; it does not mean every unlifted type. `address` requires `AddrRep`. Empty unboxed tuples and other unboxed aggregates remain `unknown`, even when their register list is empty; they are not a supported void token. Boxed `data` requires GHC's `isBoxedDataTyCon`, which excludes newtypes, type families, unary class representations and abstract types. Function types prove `closure`; other boxed types remain `object`. No classifier parses printed type strings. The category describes the value after evaluation and does not itself permit eager evaluation or skipping a force.

`evaluated` is positive WHNF evidence, independent of demand/strictness. GHC's `exprIsHNF (Var v)` recognizes already evaluated unfoldings and definitely unlifted binders. Ordinary lifted lambda parameters remain unevaluated even when their demand signature says they will be forced. A case's metadata includes a complete `binder` record marked evaluated. Each alternative appends `{binders: [fullBinderRecords...]}` at index 4, in exactly the order of its existing binder IDs. Within that branch, lexical WHNF facts also cover the original scrutinee variable (through casts/ticks) and fields marked strict in the saturated constructor worker's representation layout. These facts reach both binder records and variable uses. Lazy lifted pattern fields remain lazy. Strictness marks are applied only when they align exactly with the retained worker slots, including zero-width coercions. Rewritten wired subtrees retain conservative unknown type evidence.

Lambda metadata also includes `resultRep`, the representation of the body after all exported value/coercion lambdas have been flattened. Join bindings carry `joinValueArity` and `joinResultRep` in addition to the original diagnostic `info.joinArity`. GHC join arity counts type binders; `joinValueArity` counts only the non-type binders in that exact original prefix, retaining coercions. `joinResultRep` describes the remaining RHS after that prefix, which can itself be a lambda. A join returning a function must therefore retain the remaining lambdas rather than consume every flattened parameter. These fields follow GHC 9.14.1's `Note [Invariants on join points]` and `collectNBinders`; join arity is not `idArity`.

Bindings and their leading flattened lambda metadata also carry `entryStrict: [Boolean...]` and `entryStrictSource`. These are **requested entry obligations**, separate from `rep.evaluated`: a true position must contain an evaluated value before the function body starts. Positions count retained value/coercion arguments, erase type arguments, and are padded false through the full flattened lambda. For a join, only its original join prefix can acquire obligations; returned lambda arguments remain false. A binding without a leading lambda retains only the contract prefix on the binding record; the exporter does not attach it to an unrelated nested lambda.

`info.cbvEligible` records GHC worker/join eligibility; `info.cbvMarks` preserves `idCbvMarks_maybe` as a Boolean array or null. Current-module CBV marks are normally empty before Tidy. At that boundary, the exporter calls the pinned compiler's own `GHC.Core.Tidy.tidyCbvInfoTop emptyNameSet` selection logic on eligible definitions and records resulting requirements as `ghc-tidy-proposal`. The empty boot-export exclusion set intentionally requests a THC-internal convention, not a claim about native boot-file ABI permissions. Actual nonempty Id marks, including imported or post-Tidy marks, have source `ghc-id`. Interface unfoldings and post-Tidy exports do not derive new proposals; no contract has source `none`. The Core tree and GHC's native compilation are unchanged.

GHC's selection handles worker/join eligibility, exact join prefixes, supported single-register arguments, strict-and-used demands, dead-end exclusions, and arity trimming. We neither parse demand strings nor treat general strict demand as proof of prior evaluation. The runtime must enforce these obligations on **every saturated entry route**, including indirect calls, PAP prefixes, overapplication, host entry and local joins, before strengthening formal WHNF facts. Creating or observing an undersaturated function must not force its captured arguments. Native GHC also requires properly tagged references; this export asks THC for the analogous direct WHNF value and does not imply pointer tagging on JVM references. See the pinned [CBV invariants](https://github.com/ghc/ghc/blob/ghc-9.14.1-release/compiler/GHC/Types/Id/Info.hs) and [mark selection](https://github.com/ghc/ghc/blob/ghc-9.14.1-release/compiler/GHC/Core/Tidy.hs).

Application metadata separately carries optional `callDemand: {arity: N, strictArgs: [Boolean...]}`. This permits evaluating marked arguments when this particular application executes. `N` is the original GHC `DmdSig` argument count, obtained with `splitDmdSig`; it is independent of `idArity`, lambda count and entry obligations. `strictArgs` has exactly one position per retained argument, including coercions. Below `N` supplied positions all marks are false. Otherwise only GHC `isStrUsedDmd` demands can produce true marks; coercion positions, overapplication suffixes and arguments headed by `lazy` (also under casts/ticks) remain false. In particular, bottom demand is strict but absent and never becomes a true mark. Divergence does not add marks. No demand string is parsed.

The exporter computes the certificate from the original typed application before erasing type arguments or rewriting wired identities. Only a direct `Var` head is accepted; a head behind a cast/tick gets no certificate, conservatively respecting application boundaries. Rewritten wired subtrees also receive none. Missing metadata preserves the lazy path; malformed present certificates are errors. When caller-demand lowering is enabled, a marked position uses the runtime's existing strict argument path without allocating a fresh argument thunk. The permission stays inside evaluation of this application: it does not force enclosing lazy bindings or constructor fields, widen `entryStrict`, strengthen a formal's `rep.evaluated`, or narrow a polymorphic argument's representation. See GHC's [demand-signature threshold and strict-used distinction](https://github.com/ghc/ghc/blob/ghc-9.14.1-release/compiler/GHC/Types/Demand.hs) and [CorePrep application preparation](https://github.com/ghc/ghc/blob/ghc-9.14.1-release/compiler/GHC/CoreToStg/Prep.hs).

Caller-demand lowering is **opt-in** with `-Dthc.callDemands=true`; the default is false pending performance rollout. Each AST or bytecode program reads this property once when it is constructed. The exporter always emits structured evidence, and the runtime validates present certificates even when their lowering is disabled. This switch does not affect constructor strictness, entry contracts, WHNF evidence or speculation. The dedicated demand tests enable it locally and restore the previous property afterward.

After building the distribution and exported fixtures, opt in for a run with:

```sh
JAVA_OPTS='-Dthc.callDemands=true -Dpolyglot.compiler.InliningPolicy=Default' ./scripts/run.sh sumLoop 10000 --compile
```

`JAVA_OPTS` is read by the installed application launcher. Passing `-Dthc.callDemands=true` only to Gradle does not forward it to the test or application JVM. For benchmark comparisons, set `-Dpolyglot.compiler.InliningPolicy=Default` explicitly on both sides and vary only `thc.callDemands`; retain the same Core and runtime. The current Default comparison established no throughput win, and Agnostic regressions prevent enabling this by default. See [the demand measurements](../docs/demand-probe.md).

`scripts/check-demand-metadata.py --ghc-api` checks real `DemandAudit` and `CbvCoercionAudit` exports plus synthetic GHC API cases where signature arity differs from Id arity, type/coercion slots, overapplication, absence/bottom, dead ends, lazy wrappers, and cast/tick heads. A separate CPP-enabled export checks genuine `raiseIO#` branch/scrutinee weakening against a pure strict control; its unsupported IO paths are metadata-only and stay out of the runtime fixture. The ordinary strict-function fixture retains false entry marks and unevaluated lifted formals. `scripts/prepare-tests.sh` builds these fixtures and runs the audit; fewer argument thunks alone do not establish a performance improvement.

`lifted` is inferred from GHC's type levity. An unresolved levity is JSON null and must be rejected by the runtime if reachable. Lifted arguments preserve lazy evaluation. Unlifted arguments require evaluation before entering the callee. Constructor records carry representation arity, GHC tag, type, and kind (`boxed`, `unboxed-tuple`, `unboxed-sum`, `newtype`); presence in this export does not imply runtime support.

Unboxed sum constructor records add `sumArity`, the number of constructors in their GHC family; their ordinary `arity` is still the one logical payload. Sum representation records add `tagSlot: 0` and `alternativeSlots`, the GHC-derived zero-based payload projection into the enclosing physical `primReps`. Unknown projections remain null. These fields do not enable sum execution; see [sum layout evidence](../docs/aggregate-layout.md#sum-storage-projections).

Constructor records also carry parallel `strictFields` and `fieldLifted` arrays for the **worker representation slots**, from `dataConRepStrictness` and `dataConRepArgTys` respectively. These are not source-field strictness annotations: unpacking may change the slots. A strict lifted field carries a Core worker call-by-value obligation that argument levity alone does not enforce. The runtime must force strict lifted worker fields to WHNF at saturated construction, while retaining the original logical fields for cases and partial applications. Unresolved field levity remains an explicit capability error.

The optional fifth application element is GHC 9.14.1's `exprIsHNF` result for the **original complete Core application**, before erasing type and coercion information. `true` certifies that the application is already in weak head normal form, allowing the runtime to construct its value directly instead of wrapping that application in a thunk. GHC recognizes constructor applications and partial applications when their required argument evaluation is safe; it accounts for unlifted arguments and saturated constructor workers' strict fields. Lazy constructor fields remain lazy. `false` means no certificate, not that evaluation necessarily diverges. This does not override levity checks, constructor support checks, or strict-field evaluation obligations. See [GHC's canonical analysis](https://github.com/ghc/ghc/blob/ghc-9.14.1-release/compiler/GHC/Core/Utils.hs). The first four elements are unchanged; older schema-1 exports without the fifth element must be treated conservatively as `false`.

The optional sixth application element uses GHC's `exprOkForSpecEval` on the original Core application. It certifies that evaluation reaches WHNF promptly without an observable effect or exception, allowing direct evaluation of lifted arguments and nonrecursive let RHSs even when they contain safe primitive redexes, such as `Box (n -# 1#)`. The predicate excludes all IDs in every enclosing recursive group while traversing that group's RHSs, following CorePrep's `Note [Speculative evaluation]`; blindly using `exprOkForSpeculation` could turn a terminating recursive dictionary into an infinite evaluation. Recursive and global binding initialization still requires the runtime's separate lazy handling. The sixth flag is authoritative when present, so a recursive-scope exclusion cannot be overridden by the WHNF flag. Consumers may use the fifth flag only for older exports without the sixth; both absent means conservative lazy evaluation. Lazy lifted fields and arguments remain lazy; potentially failing unlifted computations such as division by zero do not receive the speculation certificate. Ordinary unknown or saturated function calls remain conservative.

Constructor records also include `fieldReps`, aligned with the same worker slots. Each slot is GHC's actual list of `PrimRep`s, obtained through `typePrimRep_maybe` on the representation argument type and encoded with the canonical GHC 9.14.1 constructor names (`Show PrimRep`). This is type analysis, not parsing printed type text. An empty list means zero-width; a singleton describes one runtime value; multiple entries describe a multi-register representation that the current runtime must reject explicitly. An unresolved runtime representation is JSON `null`, also requiring rejection when reachable. For example, `Box Int#` has `[["IntRep"]]`, while `Cons Box List` has `[["BoxedRep (Just Lifted)"], ["BoxedRep (Just Lifted)"]]`. A void slot has `[]`; a constructor with no fields has an empty outer `fieldReps` list. `fieldLifted` and `strictFields` remain independent metadata: pointer representation does not establish evaluation state or constructor strictness. Unsupported primitive representations must remain errors rather than defaulting to reference storage.

Constructor `fieldTypes` optionally carries a representation record per worker slot, aligned with `fieldReps`. It applies the same type classifier to the actual worker argument type; `evaluated` is true only for an unlifted slot or an exactly aligned strict-worker-field obligation. The runtime may use this to register a more precise reference field class only after it enforces that obligation. For example, ordinary Map `Bin` has `long`, `object`, `object`, `data`, `data` fields: the size is primitive, polymorphic key/value references remain generic, and strict child Maps can use the data-value class. A lazy field of a known data or function type must still accept a thunk. Newtype and family fields retain the conservative `object` category unless their actual worker type has already exposed another representation. Missing `fieldTypes` preserves generic reference storage; a type category alone never certifies WHNF.

Exactly saturated `tagToEnum#` applications retain an `enumFamily` object in their expression metadata before type arguments erase: `{typeConstructor, constructors}` contains the full type-constructor identity and ordered original nullary constructor identities. The bounded concrete enum subset requires `isEnumerationTyCon`, zero type parameters, and zero representation fields; data-family instances are excluded. Each constructor repeats its family descriptor, and dependency collection includes the whole family even when imported constructors are otherwise unused. This is nominal proof, separate from the lifted reference result representation. Missing/contradictory descriptors and bare primitive values remain unsupported; see [the runtime contract](../docs/tag-to-enum.md).

Data-constructor **workers** become constructor expressions. Constructor wrappers remain ordinary variable references and require actual compiled definitions.

### Foreign-call signature evidence

An intact, directly headed GHC `FCallId` application can additionally carry
`app[6].foreignCall`. This is structured signature evidence, **not runtime FFI
support**. Its function remains the original `var` expression and ID; unknown
foreign globals retain their existing strict frontier. No name or printed type
string is parsed to classify a call, and no Haskell body is replaced.

The schema-1 descriptor has these fields:

```json
{
  "schema": 1,
  "target": {"kind": "static", "symbol": "__hsbase_MD5Init", "unit": "main", "isFunction": true},
  "convention": "ccall",
  "safety": "unsafe",
  "arity": 2,
  "suppliedArity": 2,
  "argumentReps": [
    {"primReps": ["AddrRep"], "kind": "address", "evaluated": false},
    {"primReps": [], "kind": "void", "evaluated": false}
  ],
  "resultRep": {"primReps": [], "kind": "unknown", "evaluated": false,
                "aggregate": "unboxed-tuple",
                "components": [{"primReps": [], "kind": "void", "evaluated": true}]}
}
```

`GHC.Types.Id.isFCallId_maybe` supplies `ForeignCall`; the pinned
`GHC.Types.ForeignCall.CCallSpec` supplies all target, convention and safety
fields. A static target preserves its exact label, optional target unit (`null`
when GHC provides none), and function/data flag. The example's unit is `main`
because the compiler-only fixture belongs to that unit; it is not substituted
for the actual `ghc-internal` unit of the original Fingerprint source. A dynamic
target is exactly `{"kind":"dynamic"}`, without invented label/unit fields.
Conventions are `ccall`, `capi`, `stdcall`, `prim`, or `javascript`; safety is
`unsafe`, `safe`, or `interruptible`.

GHC's original function type is instantiated with the actual leading type
arguments before extracting declared argument and result representation records.
`arity` counts the entire instantiated signature, including zero-width State or
coercion slots; `suppliedArity` counts retained actual arguments. A consumer must
check both, the complete signature, actual argument/result proofs and exact target
contract, not merely recognize a symbol. Top-level declared `evaluated` flags are
false: the descriptor itself confers no execution/WHNF certificate. Nested
components retain the ordinary type-layout rule for known unlifted fields.
Logical tuple components remain present even when every physical register is
zero-width. Pinned `CInt` supplies `Int32Rep`, not the host `IntRep`: the MD5
Init/Update/Final declared/supplied arities are 2/4/3 including the final State.

Bare foreign variables, cast/tick function heads, still-polymorphic signatures,
interleaved type applications and export-only wired/erased subtrees do not gain
this descriptor. The ordinary export remains available and unsupported paths
remain explicit. This bounded producer introduces no new executable node kind,
general pointer support, callback implementation, or accepted-symbol whitelist.

`compiler/test-fixtures/ForeignCallAudit.hs` is compiler-only: it declares the
three MD5 machine signatures plus same-symbol safe, interruptible and wrong-type
controls, a dynamic call, an unknown symbol, and an ordinary Haskell identifier
with the same spelling. Export it before and after Tidy without linking or
executing its negative controls.

After exporting both stages, run the strict standalone reader (also with `-O`):

```sh
python3 compiler/test-fixtures/check-foreign-call-metadata.py PRE.json POST.json
```

Optional `--before PREVIOUS_PRE.json --before PREVIOUS_POST.json` additionally
checks exact expression/proof equality after removing the new descriptor and
allowing only bijective GHC-local unique renaming. This specifically includes
foreign IDs, which the general executable comparator treats as unresolved
external names. It does not parse those IDs to derive a signature. The reader
also checks the existing auditor's unchanged missing-global/host-tuple frontiers
and rejects independently mutated descriptor controls; it is not a runtime FFI
validator.

Type arguments and type lambdas erase. A type-only application becomes its function. Coercion arguments and coercion lambda binders retain a zero-width `void` slot so Core's value arity conventions remain explicit. Casts and ticks erase from the executable subset and remain visible in `sourceCore`. The source-note metadata below retains source attribution without executable tick wrappers or instrumentation events. Primitive literals retain kind, with integral/character codepoint values in decimal, byte strings in hexadecimal, floating values in decimal. Unsupported literal kinds stay explicit.

## Optional source attribution

`compiler/export.sh ...` enables GHC `-g` and the plugin's `source-notes` option by default. Set `THC_SOURCE_NOTES=false` to omit both. The Map and boot drivers use the same default and record the effective setting in provenance, so ordinary CI Map runs include source attribution. Executable schema 1 remains compatible with older exports without source metadata.

Enabled modules append `sourceFiles` records `{id,path,content}` and `sourceSpans` records `{id,file,startLine,startColumn,endLine,endColumn,charIndex,charLength,label}`. File IDs are GHC's original path strings. Span IDs are opaque deterministic strings, including the file, coordinates and label; consumers must not parse them. A module merge must reject conflicting records under an existing ID. `content` contains the actual UTF-8 source decoded as text, or null if unavailable. Installed interface notes and `LINE` pragmas can legitimately name unavailable files.

Coordinates retain GHC's original one-based, tab-expanded columns and exclusive end. `charIndex` and `charLength` are exact UTF-16 code-unit offsets into the embedded content, matching Truffle's indexing. The exporter scans real character boundaries, with eight-column tab stops and two UTF-16 units for supplementary Unicode characters. Both offsets are null when either coordinate cannot be resolved; they are never guessed from line/column values. Consumers must retain raw coordinates when content is missing or a remapped span falls outside it.

Existing expression metadata adds `source`, the innermost span ID, and `sourceNotes`, all enclosing notes in outer-to-inner order. Binder and binding records can also carry a `source` from GHC's `nameSrcSpan`, providing a fallback location for roots. Source ticks do not introduce expression wrappers, change lambda/join shape, strengthen representation certificates, or affect forcing. Other ticks still erase. GHC may move or copy notes during optimization: the records provide attribution, not exact Haskell stepping or an executed-event log.

`scripts/prepare-tests.sh` always generates source-enabled `RepresentationAudit` and `SourceNotes` fixtures in `build/source-core`, even when ordinary exports omit notes. `scripts/check-source-metadata.py --fixture build/source-core/SourceNotes.json build/source-core/RepresentationAudit.json` checks table references, nested provenance, Unicode/tab offsets and unavailable content independently of the runtime. `scripts/compare-executable-core.py BEFORE AFTER` compares executable trees after lexical alpha renaming while retaining runtime proof and constructor metadata; it ignores source metadata and diagnostic pretty text. It reports structural differences rather than claiming general equivalence between different optimized trees.

## Scope and checks

The runtime selects a root and checks the reachable definitions; it must fail closed for unknown reachable external names, primops, constructor representations or expression/literal forms. Unreachable GHC-generated Typeable metadata remains in the module. Exporting a module is not a claim that the runtime can execute every binding in it.

`export.sh` uses `--make` so imported **source modules** are exported too, and accepts normal additional GHC flags. It does not recover full executable optimized Core for preinstalled library packages from `.hi` files. Boot-library source compilation and package closure extraction are still required for general Haskell programs.

Environment overrides: `GHC` and `GHC_PKG` select the compiler and package-manager executables (both must report 9.14.1); `THC_CORE_OUT` and `THC_GHC_OUT` choose export and object directories. `THC_SOURCE_NOTES=false` opts out of the default source metadata and `-g` for source and boot exports. The plugin uses a local package database in `build/compiler/package.conf.d`; it does not modify the user's global GHC package database.

The compiler-only speculation regression runs as part of `scripts/try.sh`. To run it without building the JVM runtime:

```sh
compiler/build.sh
compiler/export.sh compiler/test-fixtures/SpeculationAudit.hs compiler/test-fixtures/RepresentationAudit.hs
python3 scripts/check-speculation-metadata.py
python3 scripts/check-representation-metadata.py
```

The check inspects actual optimized Core: safe subtraction and constant nonzero division, rejected division by zero inside a lazy argument, a PAP/lazy field containing bottom, and a saturated recursive DFun call excluded by its enclosing group. This fixture tests exporter analysis; its dictionaries and division primops do not expand runtime support. The representation fixture separately checks primitive, boxed, newtype and family categories; lazy versus strict pattern fields; a polymorphic join whose type parameter erases; and a join that returns a further lambda. Compiler-only unsupported types in that fixture do not enlarge runtime support.

## Ordinary Map dependency export

`compiler/export-map.sh` produces `build/map/modules.txt` and `build/map/provenance.json` for `THC.MapWorkload.mapAggregate`. It verifies the SHA256 of the upstream containers-0.8 archive and every vendored file, then compiles the unmodified package sources together with the ordinary workload in one coherent `main` home unit. This exports the complete source bodies of the modules GHC builds; no container operation is a JVM builtin.

The plugin option `closure=mapAggregate` traverses all lexical term references from that root, following complete source definitions recorded during the same compilation. For external definitions it uses GHC's actual `maybeUnfoldingTemplate` on Core/DFun unfoldings. Their `origin` and `originModule` are recorded. Missing interface bodies are reported explicitly; interfaces are not assumed to contain complete packages.

`compiler/export-boot.py` adds the original GHC 9.14.1 `CString` and `Err` source modules under their actual wired `ghc-internal` unit. A private interface overlay points to installed dynamic interfaces; source outputs replace only files in the private build directory. Installed packages are not changed. The `post-tidy` plugin option uses GHC's `latePlugin`/`CgGuts` boundary after Tidy and before CorePrep, explicitly recorded in each module. This retains the real generated private names and implicit bindings needed for package identity; the ordinary application and containers exports remain before Tidy.

Its `--frontier lists` mode instead exports the complete original `Base` and `List` modules, resolving the installed Prelude's missing `(++)` and `reverse1` executable bodies. All sources and their five boot dependencies are checked against pinned SHA256 hashes. This mode loads the compiled exporter with `-fplugin-library`, avoiding plugin interface dependencies that would otherwise import `Base` instances into the unit being rebuilt. The coverage corpus retains the original missing-interface report and verifies exact identity resolution by these post-Tidy source exports; no identities or algorithms are substituted.

A compiler-only interface root exposes the actual installed non-boot exception-construction unfolding, including its real exception/backtrace dependencies. The resulting bundle deliberately records a **bounded compatibility frontier**, not a complete boot library: missing bodies and unsupported operations remain visible in `scripts/audit-core.py --entry mapAggregate --module-list build/map/modules.txt`. GHC 9.14's error construction reaches state, mutable references and backtrace machinery. A successful diagnostic run on inputs that avoid those paths does not establish their support.

`Thc.Wired` performs GHC's canonical late erasure of unary-class constructors/selectors, `lazy`/`noinline`/`nospec`, `runRW#`, and the zero-width real-world state token; ordinary class selectors use GHC's own generator. This is compiler representation lowering, not a replacement library algorithm. Both serialization and dependency discovery apply the same lowering. Rewritten subtrees receive conservative evaluation certificates because representation-erased unary templates are no longer typed Core; they are never inserted back into GHC's optimized program or Core lint.

The Map driver also writes `build/map/reproduction-provenance.json`. It hashes the current bundle, source inputs, exporter implementation, explicit compiler flag recipes, and the installed dynamic interfaces that own the executable unfoldings included in the bundle. Interface coverage is stated explicitly: this is not a complete archive of every transitive interface GHC may consult for types or rewrite rules. It records the selected GHC/package-manager paths, versions, package metadata and GHC build configuration. Both tools are selected consistently through `GHC`/`GHC_PKG` and pinned to 9.14.1.

To supplement an existing measured bundle without recompiling or rewriting its Core JSON, run `python3 compiler/reproduction-provenance.py`. The supplement distinguishes this recording mode from a fresh export; hashes identify the files present at recording time and do not claim that the compilation was replayed. The driver emits the same supplement automatically after a fresh export. GHC uniques may change across recompilations, so this is an input/provenance record, not a promise of byte-identical JSON.

## Fresh-checkout build

Use GHC/ghc-pkg 9.14.1, Python 3.12 or later, and GraalVM 25.3.4.1 with JDK 25. Set `JAVA_HOME` explicitly; scripts never borrow another checkout's JDK. `scripts/try.sh` builds the exporter, generates the real fixture and CString exports required by the JVM tests, creates the native oracle, then runs tests and assembles the application. Gradle downloads dependencies normally; append `--offline` only after populating the cache. `THC_GRADLE_USER_HOME` overrides `GRADLE_USER_HOME`, which otherwise defaults to the project's `.gradle-user-home`.

`scripts/try-map.sh` is also self-contained: it prepares the same test inputs, exports the Map bundle, checks capability gaps, and compares native/guest results. The current known gaps require the explicit diagnostic invocation `THC_DIAGNOSTIC_UNSUPPORTED=true scripts/try-map.sh`; the default strict invocation intentionally stops at the audit. CI runs both entrypoints on Linux and macOS, with pinned compiler/runtime versions and the compatibility audit retained as an artifact.

CI uses the upstream [GraalVM setup action](https://github.com/graalvm/setup-graalvm) with its exact GraalVM `version` and separate `java-version` inputs, and [Haskell setup](https://github.com/haskell-actions/setup) with `ghc-version: 9.14.1`. It verifies the installed release metadata before testing.
