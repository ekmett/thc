@file:Suppress("UNCHECKED_CAST")
package thc.runtime

/** Exact Core runtime kinds are independent of evidence that a lifted value is already evaluated. */
internal enum class CoreKind { LONG, FLOAT, DOUBLE, ADDRESS, VOID, DATA, CLOSURE, OBJECT, VECTOR, UNKNOWN }

internal data class CoreRepresentation(
    val kind: CoreKind,
    val evaluated: Boolean = false,
    val present: Boolean = false,
    val primReps: List<String>? = null,
    val components: List<CoreRepresentation>? = null,
    val vector: CoreVector? = null,
    val alternatives: List<CoreRepresentation>? = null,
    val tagSlot: Int? = null,
    val alternativeSlots: List<List<Int>>? = null
) {
    val isVector: Boolean get() = vector != null
    val isTuple: Boolean get() = components != null
    val isSum: Boolean get() = alternatives != null
    val isAggregate: Boolean get() = isTuple || isSum
    val isEmptyTuple: Boolean get() = present && kind == CoreKind.UNKNOWN && components?.isEmpty() == true && primReps?.isEmpty() == true
    val isLong: Boolean get() = kind == CoreKind.LONG
    val isFloat: Boolean get() = kind == CoreKind.FLOAT
    val isDouble: Boolean get() = kind == CoreKind.DOUBLE
    val isEvaluatedReference: Boolean get() = evaluated &&
        (kind == CoreKind.DATA || kind == CoreKind.CLOSURE || kind == CoreKind.ADDRESS)
    /** A lifted type alone cannot exclude a thunk; a stored WHNF proof can. */
    fun referenceCarrier(): Class<*>? = if (!evaluated) null else when (kind) {
        CoreKind.DATA -> DataValue::class.java
        CoreKind.CLOSURE -> Closure::class.java
        CoreKind.ADDRESS -> ManagedAddress::class.java
        else -> null
    }
    fun refine(other: CoreRepresentation): CoreRepresentation {
        // A Long is only the host carrier: distinct exact GHC scalar reps cannot
        // replace one another on a lexical value. Unknown/legacy proofs add no constraint.
        if (present && other.present && kind == CoreKind.LONG && other.kind == CoreKind.LONG &&
            primReps?.size == 1 && other.primReps?.size == 1 && primReps != other.primReps)
            throw RuntimeFault("Conflicting Core scalar representation proofs: $primReps and ${other.primReps}")
        val boxed = exactBoxedRep()
        val otherBoxed = other.exactBoxedRep()
        if (boxed != null && otherBoxed != null && boxed != otherBoxed)
            throw RuntimeFault("Conflicting Core boxed levity proofs: $boxed and $otherBoxed")
        if ((isVector || other.isVector) && present && other.present && vector != other.vector)
            throw RuntimeFault("Conflicting Core vector representation proofs")
        if (isAggregate && other.isAggregate && !TupleShape.compatible(this, other))
            throw RuntimeFault("Conflicting logical aggregate representation proofs")
        if (isAggregate && !other.isAggregate && (other.kind != CoreKind.UNKNOWN || other.primReps != null) ||
            other.isAggregate && !isAggregate && (kind != CoreKind.UNKNOWN || primReps != null))
            throw RuntimeFault("Conflicting scalar and aggregate representation proofs")
        val merged = when {
            kind == CoreKind.UNKNOWN -> other.kind
            other.kind == CoreKind.UNKNOWN || kind == other.kind -> kind
            kind in setOf(CoreKind.OBJECT, CoreKind.DATA, CoreKind.CLOSURE) &&
                other.kind in setOf(CoreKind.OBJECT, CoreKind.DATA, CoreKind.CLOSURE) ->
                if (other.kind == CoreKind.OBJECT) kind else other.kind
            else -> throw RuntimeFault("Conflicting Core representation proofs: $kind and ${other.kind}")
        }
        // Unknown boxed levity refines either way; it cannot erase an existing
        // exact proof and thereby hide a later contradiction. Object class and
        // evaluatedness continue to refine independently of liftedness.
        val mergedReps = if (boxed != null && other.primReps == listOf("BoxedRep Nothing")) primReps
            else other.primReps ?: primReps
        return CoreRepresentation(merged, evaluated || other.evaluated,
            present || other.present, mergedReps, other.components ?: components, other.vector ?: vector,
            other.alternatives ?: alternatives, other.tagSlot ?: tagSlot, other.alternativeSlots ?: alternativeSlots)
    }
    private fun exactBoxedRep(): String? = if (present &&
        kind in setOf(CoreKind.OBJECT, CoreKind.DATA, CoreKind.CLOSURE))
        primReps?.singleOrNull()?.takeIf { it == "BoxedRep (Just Lifted)" || it == "BoxedRep (Just Unlifted)" }
        else null
    companion object { val UNKNOWN = CoreRepresentation(CoreKind.UNKNOWN) }
}

internal object CoreRepresentations {
    private val longs = setOf("IntRep", "WordRep", "Int8Rep", "Word8Rep", "Int16Rep", "Word16Rep",
        "Int32Rep", "Word32Rep", "Int64Rep", "Word64Rep")
    /** Validate every known arm, but never infer an unknown arm from its peers. */
    fun validateFloatingCaseResult(declared: CoreRepresentation, alternatives: List<CoreRepresentation>) {
        val proofs = listOf(declared) + alternatives
        val floating = proofs.firstOrNull { it.isFloat || it.isDouble } ?: return
        proofs.forEach { floating.refine(it) }
    }
    fun validateAggregateCaseResult(declared: CoreRepresentation, alternatives: List<CoreRepresentation>) {
        val aggregate = (listOf(declared) + alternatives).firstOrNull { it.isAggregate } ?: return
        (listOf(declared) + alternatives).forEach { aggregate.refine(it) }
    }
    /** Validate every retained proof, including cold branches and unused binders. */
    fun validateAggregates(bindings: List<Map<String, Any?>>,
                           constructors: Map<String, Map<String, Any?>> = emptyMap()) {
        fun visit(value: Any?, path: List<Any>, exemptions: Set<List<Any>>) {
            when (value) {
                is Map<*, *> -> value.forEach { (key, child) ->
                    val next = path + (key ?: "<null>")
                    if (key in setOf("rep", "resultRep", "joinResultRep") && child is Map<*, *> && next !in exemptions) parse(child)
                    visit(child, next, exemptions)
                }
                is List<*> -> {
                    // Only these structural sites are exempt: shared/equal proof maps
                    // elsewhere (including function results) still use generic parse.
                    val local = if (CoreVectorMemory.readCase(value, constructors) != null)
                        exemptions + setOf(path + listOf(1, 6, "rep"), path + listOf(4, "binder", "rep"))
                    else exemptions
                    value.forEachIndexed { index, child -> visit(child, path + index, local) }
                }
            }
        }
        visit(bindings, emptyList(), emptySet())
    }
    /** Known host aliases and partial applications retain their remaining ABI. */
    fun knownFunctionSignature(expression: List<Any?>, bindings: List<Map<String, Any?>>): Pair<List<CoreRepresentation>, CoreRepresentation>? {
        val globals = bindings.associateBy { it["id"] as String }
        fun resolve(expr: List<Any?>, seen: Set<String>): Pair<List<CoreRepresentation>, CoreRepresentation>? = when (expr.firstOrNull()) {
            "lam" -> (expr[1] as List<Map<String, Any?>>).map(::binder) to lambdaResult(expr)
            "var" -> (expr[1] as String).let { id ->
                if (id in seen) null else (globals[id]?.get("expr") as? List<Any?>)?.let { resolve(it, seen + id) }
            }
            "app" -> resolve(expr[1] as List<Any?>, seen)?.let { (inputs, result) ->
                val supplied = (expr[2] as List<*>).size
                if (supplied < inputs.size) inputs.drop(supplied) to result else null
            }
            else -> null
        }
        return resolve(expression, emptySet())
    }
    fun knownFunctionResult(expression: List<Any?>, bindings: List<Map<String, Any?>>): CoreRepresentation? =
        knownFunctionSignature(expression, bindings)?.second
    fun requireInput(proof: CoreRepresentation) {
        if (proof.isTuple) {
            TupleShape.validate(proof)
            if (TupleShape.flatten(proof).any { it.primReps == listOf("BoxedRep Nothing") })
                throw UnsupportedCore("Unsupported Core tuple input with unknown boxed levity")
        } else requireScalar(proof, "argument")
    }
    /** Joins retain logical arity; only the exact nullary tuple has no input slot. */
    fun requireJoinInput(proof: CoreRepresentation) {
        if (!proof.isEmptyTuple) requireScalar(proof, "join argument")
    }
    fun requireJoinArgument(expected: CoreRepresentation, actual: CoreRepresentation) {
        requireJoinInput(actual)
        if (expected.isEmptyTuple || actual.isEmptyTuple) {
            if (!expected.isEmptyTuple || !actual.isEmptyTuple)
                throw RuntimeFault("Local join requires matching exact empty tuple argument proof")
        }
    }
    fun requireScalar(proof: CoreRepresentation, boundary: String) {
        requireNoVector(proof, boundary)
        if (proof.isSum) throw UnsupportedCore("Unsupported Core aggregate representation: unboxed-sum ($boundary)")
        if (proof.isTuple) throw UnsupportedCore("Unsupported Core aggregate representation: unboxed-tuple ($boundary)")
    }
    fun requireNoSum(proof: CoreRepresentation, boundary: String) {
        if (proof.isSum) throw UnsupportedCore("Unsupported Core aggregate representation: unboxed-sum ($boundary)")
    }
    fun requireNoVector(proof: CoreRepresentation, boundary: String) {
        if (proof.isVector) throw UnsupportedCore("Unsupported Core vector boundary: $boundary")
    }
    fun parse(value: Any?): CoreRepresentation {
        if (value == null) return CoreRepresentation.UNKNOWN
        val map = value as? Map<String, Any?> ?: throw RuntimeFault("Invalid Core representation metadata")
        val components = when (val aggregate = map["aggregate"]) {
            null -> null
            "unboxed-sum" -> null
            "unboxed-tuple" -> (map["components"] as? List<*>)?.map(::parse)
                ?: throw UnsupportedCore("Unsupported Core aggregate representation: unboxed-tuple lacks exact components")
            else -> throw RuntimeFault("Invalid Core aggregate representation: $aggregate")
        }
        if (map["aggregate"] == "unboxed-sum" && "components" in map)
            throw RuntimeFault("Sum proof contains tuple components")
        val alternatives = if (map["aggregate"] == "unboxed-sum")
            (map["alternatives"] as? List<*>)?.map(::parse)
                ?: throw UnsupportedCore("Unsupported Core aggregate representation: unboxed-sum lacks exact alternatives")
            else null
        fun exactInt(value: Any?): Int {
            if (value !is Long && value !is Int) throw RuntimeFault("Invalid sum slot index")
            val number = value as Number
            val index = number.toInt()
            if (number.toDouble() != index.toDouble()) throw RuntimeFault("Invalid sum slot index")
            return index
        }
        val tagSlot = if (alternatives != null) exactInt(map["tagSlot"]) else null
        val projections = if (alternatives != null) (map["alternativeSlots"] as? List<*>)?.map { row ->
            (row as? List<*>)?.map(::exactInt) ?: throw RuntimeFault("Invalid sum alternative projection")
        } ?: throw UnsupportedCore("Unsupported Core aggregate representation: unboxed-sum lacks exact projection") else null
        val kind = when (map["kind"]) {
            "long" -> CoreKind.LONG; "address" -> CoreKind.ADDRESS; "void" -> CoreKind.VOID
            "float" -> CoreKind.FLOAT; "double" -> CoreKind.DOUBLE
            "data" -> CoreKind.DATA; "closure" -> CoreKind.CLOSURE; "object" -> CoreKind.OBJECT
            "vector" -> CoreKind.VECTOR
            "unknown" -> CoreKind.UNKNOWN
            else -> throw RuntimeFault("Unknown Core representation kind ${map["kind"]}")
        }
        val reps = map["primReps"]?.let { values ->
            (values as? List<*>)?.map { it as? String ?: throw RuntimeFault("Invalid Core primitive representation") }
                ?: throw RuntimeFault("Invalid Core primitive representations")
        }
        if (kind == CoreKind.LONG && (reps?.size != 1 || reps[0] !in longs))
            throw RuntimeFault("Core Long proof lacks a supported primitive representation")
        if (kind == CoreKind.ADDRESS && reps != listOf("AddrRep"))
            throw RuntimeFault("Core address proof lacks AddrRep")
        if (kind == CoreKind.FLOAT && reps != listOf("FloatRep"))
            throw RuntimeFault("Core Float proof lacks FloatRep")
        if (kind == CoreKind.DOUBLE && reps != listOf("DoubleRep"))
            throw RuntimeFault("Core Double proof lacks DoubleRep")
        if (kind == CoreKind.VOID && reps != emptyList<String>())
            throw RuntimeFault("Core void proof has payload registers")
        if (kind in setOf(CoreKind.DATA, CoreKind.CLOSURE, CoreKind.OBJECT) &&
            (reps?.size != 1 || reps[0] !in setOf("BoxedRep (Just Lifted)", "BoxedRep (Just Unlifted)", "BoxedRep Nothing")))
            throw RuntimeFault("Core reference proof lacks a single boxed representation")
        val vector = CoreVector.parse(map["vector"], kind, reps, components != null || alternatives != null)
        val evaluated = map["evaluated"] as? Boolean ?: throw RuntimeFault("Missing Core evaluatedness proof")
        val proof = CoreRepresentation(kind, evaluated, true, reps, components, vector, alternatives, tagSlot, projections)
        if (components != null) TupleShape.validate(proof)
        if (alternatives != null) SumShape.validate(proof)
        return proof
    }
    fun binder(binding: Map<String, Any?>): CoreRepresentation = parse(binding["rep"])
    fun metadata(expr: List<Any?>): Map<String, Any?>? {
        val index = when (expr.firstOrNull()) {
            "var", "prim" -> 2; "lit", "lam", "con" -> 3; "app" -> 6
            "let", "case" -> 4; "void" -> 1; else -> return null
        }
        return expr.getOrNull(index) as? Map<String, Any?>
    }
    fun expression(expr: List<Any?>): CoreRepresentation =
        // BigNat syntax intrinsically denotes an unlifted ByteArray#, including
        // when an exporter identity rewrite erased occurrence metadata. All
        // consumers (not just literal lowering) need the same concrete proof.
        if (expr.firstOrNull() == "lit" && expr.getOrNull(1) == "bignat") BigNatLiterals.proof(expr)
        else parse(metadata(expr)?.get("rep"))
    /** Narrow literals have intrinsic signed/unsigned identity, not merely a
     * Long carrier. Missing legacy metadata is fine; a contradictory proof is not. */
    fun narrowLiteralProof(expr: List<Any?>): CoreRepresentation {
        val expected = when (expr[1]) {
            "int8" -> "Int8Rep"; "word8" -> "Word8Rep"
            "int16" -> "Int16Rep"; "word16" -> "Word16Rep"
            "int32" -> "Int32Rep"; "word32" -> "Word32Rep"
            else -> throw RuntimeFault("Not a supported narrow literal: ${expr[1]}")
        }
        val proof = expression(expr)
        // Export-only identity rewrites retain an explicit unconstrained proof.
        // The literal still supplies its own exact representation; malformed
        // records have already failed parse(), and retained constraints must match.
        val unconstrained = proof.kind == CoreKind.UNKNOWN && proof.primReps == null && !proof.isAggregate && !proof.isVector
        if (proof.present && !unconstrained &&
            (proof.kind != CoreKind.LONG || proof.primReps != listOf(expected) || proof.isAggregate || proof.isVector))
            throw RuntimeFault("${expr[1]} literal requires exact $expected metadata")
        return CoreRepresentation(CoreKind.LONG, evaluated = true, present = true, primReps = listOf(expected))
    }
    fun lambdaResult(expr: List<Any?>): CoreRepresentation = parse(metadata(expr)?.get("resultRep"))
    fun caseBinder(expr: List<Any?>): CoreRepresentation =
        (metadata(expr)?.get("binder") as? Map<String, Any?>)?.let(::binder) ?: CoreRepresentation.UNKNOWN
    fun alternativeBinders(alt: List<Any?>): List<Map<String, Any?>> =
        (alt.getOrNull(4) as? Map<String, Any?>)?.get("binders") as? List<Map<String, Any?>> ?: emptyList()
    fun joinArity(binding: Map<String, Any?>): Int? {
        val value = binding["joinValueArity"] ?: return null
        val number = value as? Number ?: throw RuntimeFault("Invalid join value arity")
        val result = number.toInt()
        if (result < 0 || number.toDouble() != result.toDouble()) throw RuntimeFault("Invalid join value arity")
        return result
    }
    fun joinResult(binding: Map<String, Any?>): CoreRepresentation = parse(binding["joinResultRep"])
}

internal data class CoreJoinDefinition(val binding: Map<String, Any?>, val id: String,
    val parameters: List<Map<String, Any?>>, val body: List<Any?>, val result: CoreRepresentation)

/** Join annotations refer to retained value/coercion arguments, never GHC's pre-erasure arity. */
internal object CoreJoins {
    fun definitions(group: List<Map<String, Any?>>): List<CoreJoinDefinition>? {
        val arities = group.map(CoreRepresentations::joinArity)
        if (arities.all { it == null }) return null
        if (arities.any { it == null }) throw UnsupportedCore("Mixed local join and ordinary binding group")
        return group.mapIndexed { index, binding ->
            val arity = arities[index]!!
            val rhs = binding["expr"] as? List<Any?> ?: throw RuntimeFault("Join binding has no expression")
            val parameters: List<Map<String, Any?>>
            val body: List<Any?>
            if (arity == 0) { parameters = emptyList(); body = rhs }
            else {
                if (rhs.firstOrNull() != "lam") throw RuntimeFault("Join value arity exceeds its lambda prefix")
                val all = rhs[1] as List<Map<String, Any?>>
                if (arity > all.size) throw RuntimeFault("Join value arity exceeds its lambda prefix")
                if (arity == all.size) {
                    val result = CoreRepresentations.joinResult(binding)
                    TupleShape.requireCompatible(result, CoreRepresentations.lambdaResult(rhs))
                }
                parameters = all.take(arity)
                body = if (arity == all.size) rhs[2] as List<Any?> else {
                    val meta = CoreRepresentations.metadata(rhs)?.toMutableMap() ?: linkedMapOf()
                    binding["joinResultRep"]?.let { meta["rep"] = it }
                    if (meta.containsKey("entryStrict")) meta["entryStrict"] = CoreEntries.lambda(rhs).drop(arity)
                    listOf("lam", all.drop(arity), rhs[2], meta)
                }
            }
            CoreRepresentations.requireNoSum(CoreRepresentations.joinResult(binding), "join result")
            CoreJoinDefinition(binding, binding["id"] as String, parameters, body, CoreRepresentations.joinResult(binding))
        }
    }

    fun validate(group: List<Map<String, Any?>>, body: List<Any?>, recursive: Boolean) {
        val joinsInGroup = definitions(group) ?: return
        val arities = joinsInGroup.associate { it.id to it.parameters.size }
        fun visit(expr: List<Any?>, tail: Boolean, shadowed: Set<String>) {
            fun isJoin(id: String) = id in arities && id !in shadowed
            when (expr.firstOrNull()) {
                "var" -> {
                    val id = expr[1] as String
                    if (isJoin(id) && (!tail || arities.getValue(id) != 0))
                        throw RuntimeFault("Local join escapes or is not exactly saturated: $id")
                }
                "app" -> {
                    val function = expr[1] as List<Any?>
                    val args = expr[2] as List<List<Any?>>
                    val id = if (function.firstOrNull() == "var") function[1] as String else null
                    if (id != null && isJoin(id)) {
                        if (!tail || args.size != arities.getValue(id))
                            throw RuntimeFault("Local join must be exactly saturated in tail position: $id")
                    } else visit(function, false, shadowed)
                    args.forEach { visit(it, false, shadowed) }
                }
                "lam" -> {
                    val ids = (expr[1] as List<Map<String, Any?>>).map { it["id"] as String }
                    visit(expr[2] as List<Any?>, false, shadowed + ids)
                }
                "let" -> {
                    val nested = expr[2] as List<Map<String, Any?>>
                    val ids = nested.map { it["id"] as String }.toSet()
                    val rhsScope = if (expr[1] == true) shadowed + ids else shadowed
                    val joins = definitions(nested)
                    if (joins != null) joins.forEach {
                        visit(it.body, tail, rhsScope + it.parameters.map { p -> p["id"] as String })
                    } else nested.forEach { visit(it["expr"] as List<Any?>, false, rhsScope) }
                    visit(expr[3] as List<Any?>, tail, shadowed + ids)
                }
                "case" -> {
                    visit(expr[1] as List<Any?>, false, shadowed)
                    (expr[3] as List<List<Any?>>).forEach {
                        visit(it[3] as List<Any?>, tail, shadowed + (expr[2] as String) + (it[2] as List<String>))
                    }
                }
            }
        }
        val ids = arities.keys
        joinsInGroup.forEach {
            visit(it.body, true, (if (recursive) emptySet() else ids) + it.parameters.map { p -> p["id"] as String })
        }
        visit(body, true, emptySet())
    }
}
