#!/usr/bin/env python3
"""Manual CI orchestration: freeze inputs, check Map, then compare serially.

All timings belong to this GitHub-hosted machine. Absolute values must not be
compared with the historical local M3 runs. Timing uses frozen JARs; the optional
compact-header compatibility step separately reruns the source test suite.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import sys
import xml.etree.ElementTree as ET

ORIGINAL = '4c116a8493eafad4077a1c5eb9c046bff56fe3c4'
POLICY = ['-Dpolyglot.compiler.InliningRecursionDepth=2',
          '-Dpolyglot.compiler.InliningExpansionBudget=12000',
          '-Dpolyglot.compiler.InliningInliningBudget=12000']
def runtime_flags(*, class_owned=True, constructor_class=False, unchecked=False,
                  leading_case=False, typed_cases=False, boxed_cache=False, compact=True):
    """Freeze every current experimental toggle; defaults must not change controls."""
    values = {'classOwnedLayouts': class_owned, 'constructorClassIdentity': constructor_class,
              'staticShapeUnchecked': unchecked, 'leadingCaseReturn': leading_case,
              'typedCases': typed_cases, 'boxedValueCache': boxed_cache}
    return ['-Dthc.' + name + '=' + str(value).lower() for name, value in values.items()] + [
        '-XX:' + ('+' if compact else '-') + 'UseCompactObjectHeaders']


CONFIGURATIONS = {
    'original': ('original', ['-XX:+UseCompactObjectHeaders']),
    'class-owned-baseline': ('current', runtime_flags()),
    # Class-owned matching bypasses constructorClassIdentity. Its isolated ablation
    # deliberately retains per-object layout storage in both configurations.
    'layout-bearing-class-off': ('current', runtime_flags(class_owned=False)),
    'layout-bearing-class-on': ('current', runtime_flags(class_owned=False, constructor_class=True)),
    'layout-bearing-unchecked-class-on': ('current', runtime_flags(class_owned=False, constructor_class=True, unchecked=True)),
    'class-owned-noncompact': ('current', runtime_flags(compact=False)),
}
COMPARISONS = {
    'original-vs-current': ('original', 'class-owned-baseline'),
    'constructor-class': ('layout-bearing-class-off', 'layout-bearing-class-on'),
    'owned-storage': ('layout-bearing-class-on', 'layout-bearing-unchecked-class-on'),
    'compact-headers': ('class-owned-noncompact', 'class-owned-baseline'),
}
REQUIRED_COMPARISONS = tuple(name for name in COMPARISONS if name != 'compact-headers')
REQUIRED_CONFIGURATIONS = tuple(dict.fromkeys(
    config for name in REQUIRED_COMPARISONS for config in COMPARISONS[name]))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def revision(path):
    return subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()


def copy_file(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def selected_suite(args):
    suite = args.suite or 'standard'
    options = {name: getattr(args, name) == 'true'
               for name in ('constructor_class', 'unchecked', 'compact_headers')}
    if suite in ('standard', 'all-on') and any(options.values()):
        raise ValueError('Combination flags require --suite combined')
    if suite == 'standard':
        configurations, comparisons = CONFIGURATIONS, COMPARISONS
        required_configs, required_comparisons = REQUIRED_CONFIGURATIONS, REQUIRED_COMPARISONS
    elif suite == 'combined':
        if not any(options.values()):
            raise ValueError('Combined suite requires at least one selected flag')
        configurations = {
            'combination-control': ('current', runtime_flags(compact=False)),
            'selected-combination': ('current', runtime_flags(
                constructor_class=options['constructor_class'], unchecked=options['unchecked'],
                compact=options['compact_headers']))}
        comparisons = {'combined': ('combination-control', 'selected-combination')}
        required_configs, required_comparisons = tuple(configurations), tuple(comparisons)
    elif suite == 'all-on':
        options = dict.fromkeys(('class_owned', 'constructor_class', 'unchecked',
                                'leading_case', 'typed_cases', 'boxed_cache', 'compact_headers'), True)
        configurations = {
            'class-owned-baseline': CONFIGURATIONS['class-owned-baseline'],
            'all-on': ('current', runtime_flags(constructor_class=True, unchecked=True,
                                              leading_case=True, typed_cases=True, boxed_cache=True))}
        comparisons = {'all-on': ('class-owned-baseline', 'all-on')}
        required_configs, required_comparisons = tuple(configurations), tuple(comparisons)
    else:
        raise ValueError('Unknown suite: ' + str(suite))
    return {'suite': suite, 'selectedOptions': options, 'configurations': configurations,
            'comparisons': comparisons, 'requiredConfigurations': required_configs,
            'requiredComparisons': required_comparisons}


def suite_config(out):
    return json.loads((out / 'frozen/suite.json').read_text())


def freeze(out, baseline, selection):
    root = Path(__file__).resolve().parents[1]
    checkouts = [('current', root)]
    if selection['suite'] == 'standard':
        assert baseline is not None, 'Pass --baseline-checkout for the standard suite'
        baseline = baseline.resolve(strict=True)
        assert revision(baseline) == ORIGINAL, 'Unexpected baseline checkout'
        checkouts.insert(0, ('original', baseline))
    frozen = out / 'frozen'
    assert not frozen.exists(), 'Frozen inputs already exist'
    frozen.mkdir(parents=True)
    for name, checkout in checkouts:
        libraries = sorted((checkout / 'build/install/thc/lib').glob('*.jar'))
        assert libraries, f'Missing built libraries: {name}'
        for path in libraries:
            copy_file(path, frozen / name / 'lib' / path.name)
        shutil.copytree(checkout / 'src/main', frozen / name / 'src/main')
    if selection['suite'] != 'standard':
        shutil.copytree(root / 'src/test', frozen / 'current/src/test')
    write_json(frozen / 'suite.json', dict(selection, currentCommit=revision(root)))
    source_manifest = root / 'build/map/modules.txt'
    modules = [(source_manifest.parent / line.strip()).resolve(strict=True)
               for line in source_manifest.read_text().splitlines() if line.strip()]
    assert modules and len(modules) == len(set(modules))
    copied_modules = []
    for index, path in enumerate(modules):
        target = frozen / 'map' / f'{index:02}-{path.name}'
        copy_file(path, target)
        copied_modules.append(target)
    (frozen / 'map/modules.txt').write_text(''.join(str(path) + '\n' for path in copied_modules))
    copy_file(root / 'build/map/native/native-oracle', frozen / 'map/native-oracle')
    copy_file(root / 'build/map/oracle.tsv', frozen / 'map/oracle.tsv')
    for name in ('ci-performance.py', 'compare-map-runtimes.py'):
        copy_file(root / 'tools' / name, frozen / 'helpers' / name)
    copy_file(root / '.github/workflows/performance.yml', frozen / 'helpers/performance.yml')
    for name in ('object-sizes.py', 'ObjectSizes.java', 'ObjectSizesAgent.java'):
        copy_file(root / 'bench/results/constructor-class/object-sizes' / name, frozen / 'helpers' / name)
    shutil.copytree(root / 'build/test-results/test', out / 'test-results/default')
    records = [{'path': str(path.relative_to(frozen)), 'sha256': sha(path)}
               for path in sorted(frozen.rglob('*')) if path.is_file()]
    for record in records:
        path = frozen / record['path']
        path.chmod(path.stat().st_mode & ~0o222)
    write_json(out / 'immutable-manifest.json', {'files': records})
    write_json(out / 'run.json', {
        'recordedAtUtc': datetime.now(timezone.utc).isoformat(),
        'scope': 'New GitHub-hosted macOS hardware; compare only within this run, not absolute local M3 timings.',
        'originalCommit': ORIGINAL if selection['suite'] == 'standard' else None,
        'currentCommit': revision(root), 'repository': str(root),
        'host': {'system': platform.system(), 'machine': platform.machine(), 'platform': platform.platform()},
        'githubRunId': os.environ.get('GITHUB_RUN_ID'), 'githubRunAttempt': os.environ.get('GITHUB_RUN_ATTEMPT'),
        'policy': POLICY, **selection,
        'sharedCore': 'All compared configurations use this one current exported Core/native corpus.',
        'protocol': 'Full MapCheck uses counters to verify installed code; timing harness instrumentation is disabled.',
        'commands': [],
    })
    (out / 'logs').mkdir(exist_ok=True)
    print(f'Frozen {len(records)} files for {selection["suite"]}, with one shared current Core/native corpus.', flush=True)


def verify(out):
    frozen = out / 'frozen'
    records = json.loads((out / 'immutable-manifest.json').read_text())['files']
    assert sorted(str(path.relative_to(frozen)) for path in frozen.rglob('*') if path.is_file()) == sorted(record['path'] for record in records), 'Frozen file inventory changed'
    for record in records:
        assert sha(frozen / record['path']) == record['sha256'], f'Frozen input changed: {record["path"]}'


def run(out, command, name, timeout, environment=None):
    config = json.loads((out / 'run.json').read_text())
    record = {'argv': list(map(str, command)), 'log': f'logs/{name}.log'}
    if environment:
        record['environmentOverrides'] = environment
    config['commands'].append(record)
    write_json(out / 'run.json', config)
    print(f'Starting {name}', flush=True)
    try:
        with (out / record['log']).open('w') as log:
            process = subprocess.Popen(record['argv'], stdout=log, stderr=subprocess.STDOUT,
                                       env={**os.environ, **environment} if environment else None, start_new_session=True)
            try:
                returncode = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                record['timedOut'] = True
                # Stop children as well, so a failed optional lane cannot leave JVMs running.
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass
                finally:
                    # The leader can exit before its child JVMs; kill the whole group anyway.
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait()
                raise
        record['returncode'] = returncode
    finally:
        write_json(out / 'run.json', config)
    if returncode:
        print('\n'.join((out / record['log']).read_text(errors='replace').splitlines()[-60:]), file=sys.stderr)
        raise RuntimeError(f'{name} failed with status {returncode}')
    print(f'Completed {name}', flush=True)
    return out / record['log']


def check_configuration(out, java, name, compact_control=None):
    frozen = out / 'frozen'
    runtime, flags = suite_config(out)['configurations'][name]
    flags = list(flags)
    suffix = ""
    if compact_control is not None:
        flags.append('-XX:' + ('+' if compact_control else '-') + 'UseCompactObjectHeaders')
        suffix = '-compact-on' if compact_control else '-compact-off'
    expected = [line.split('\t') for line in (frozen / 'map/oracle.tsv').read_text().splitlines() if line]
    assert len(expected) == 18, 'Expected the full 18-input Map oracle'
    verify(out)
    command = [java, '-XX:+UseCompactObjectHeaders', '--enable-native-access=ALL-UNNAMED', '-Xss2m', *POLICY, *flags,
               '-Dthc.backend=bytecode', '-Dthc.diagnosticUnsupported=true', '-Dthc.sourceNotesEnabled=true',
               '-Dthc.traceCompilation=true', '-cp', str(frozen / runtime / 'lib/*'), 'thc.MapCheckKt',
               frozen / 'map/modules.txt', frozen / 'map/oracle.tsv']
    log = run(out, command, 'check-' + name + suffix, 600)
    lines = log.read_text().splitlines()
    for phase in ('before-requested-compilation', 'after-requested-compilation'):
        actual = [line.split('\t')[2:] for line in lines if line.startswith('VERIFIED_MAP\t' + phase + '\t')]
        assert actual == [row[1:] for row in expected], f'Incomplete Map check: {name} {phase}'
    diagnostics = json.loads(next(line.removeprefix('MAP_DIAGNOSTICS ') for line in lines if line.startswith('MAP_DIAGNOSTICS ')))
    assert diagnostics['backend'] == 'bytecode' and diagnostics['unsupportedTraps'] == 0
    assert diagnostics['sourceNotesEnabled'] is True and diagnostics['sourceRootCount'] > 0
    return {'configuration': name, 'compactControl': compact_control, 'beforeRows': 18, 'afterRows': 18, 'diagnostics': diagnostics}


def check(out, java):
    results = []
    required = suite_config(out)['requiredConfigurations']
    for name in required:
        results.append(check_configuration(out, java, name))
        write_json(out / 'checks.json', {'passed': len(results) == len(required), 'configurations': results})
    verify(out)


def compare(out, name, java_home):
    checks = json.loads((out / 'checks.json').read_text())
    assert checks['passed'] is True, 'All Map configurations must pass before timing'
    if name == 'compact-headers':
        assert json.loads((out / 'compact-status.json').read_text())['readyToTime'] is True
    elif name in ('combined', 'all-on'):
        assert json.loads((out / 'combined-status.json').read_text())['compatibilityPassed'] is True
    verify(out)
    frozen = out / 'frozen'
    selection = suite_config(out)
    left, right = selection['comparisons'][name]
    baseline, baseline_flags = selection['configurations'][left]
    candidate, candidate_flags = selection['configurations'][right]
    config = json.loads((out / 'run.json').read_text())
    command = [sys.executable, frozen / 'helpers/compare-map-runtimes.py',
               frozen / baseline / 'lib', frozen / candidate / 'lib', frozen / 'map/native-oracle',
               frozen / 'map/modules.txt', out / 'comparisons' / name, '--java-home', java_home,
               '--baseline-commit', ORIGINAL if baseline == 'original' else config['currentCommit'],
               '--candidate-source-dir', frozen / candidate / 'src/main',
               '--baseline-backend', 'bytecode', '--candidate-backend', 'bytecode',
               '--baseline-source-notes', 'on', '--candidate-source-notes', 'on']
    command += ['--baseline-jvm-option=' + flag for flag in POLICY + baseline_flags]
    command += ['--candidate-jvm-option=' + flag for flag in POLICY + candidate_flags]
    run(out, command, 'compare-' + name, 3000)
    validation = json.loads((out / 'comparisons' / name / 'validation.json').read_text())
    assert validation['passed'] is True and validation['validatedWindows'] == 45
    verify(out)


def full_tests(out, name, flags):
    root = Path(json.loads((out / 'run.json').read_text())['repository'])
    source = root / 'build/test-results/test'
    destination = out / 'test-results' / name
    assert not destination.exists(), 'Compatibility results already exist'
    # Default results are already archived. Do not mistake stale XML for this run.
    if source.exists():
        shutil.rmtree(source)
    totals = {'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
    try:
        compact = True
        for flag in flags:
            if flag == '-XX:+UseCompactObjectHeaders': compact = True
            elif flag == '-XX:-UseCompactObjectHeaders': compact = False
        run(out, [root / 'scripts/gradle.sh', '--no-daemon',
                  '-Pthc.compactObjectHeaders=' + str(compact).lower(), 'test', '--rerun'],
            name + '-full-tests', 1500, {'JAVA_TOOL_OPTIONS': ' '.join(flags)})
    finally:
        if source.exists():
            shutil.copytree(source, destination)
        for path in destination.glob('TEST-*.xml'):
            suite = ET.parse(path).getroot()
            for key in totals:
                totals[key] += int(suite.attrib.get(key, 0))
        write_json(out / (name + '-test-totals.json'), totals)
    assert totals['tests'] >= 148 and all(totals[key] == 0 for key in ('failures', 'errors', 'skipped')), totals
    return totals


def verify_test_sources(out):
    root = Path(json.loads((out / 'run.json').read_text())['repository'])
    assert revision(root) == suite_config(out)['currentCommit'], 'Source commit changed'
    for subtree in ('src/main', 'src/test'):
        frozen = out / 'frozen/current' / subtree
        expected = {str(path.relative_to(frozen)): sha(path) for path in frozen.rglob('*') if path.is_file()}
        actual = {str(path.relative_to(root / subtree)): sha(path)
                  for path in (root / subtree).rglob('*') if path.is_file()}
        assert actual == expected, 'Compatibility source tree changed: ' + subtree


def combined(out, java_home):
    selection = suite_config(out)
    assert selection['suite'] in ('combined', 'all-on'), 'Selected action requires combined or all-on suite'
    comparison, = selection['requiredComparisons']
    _, candidate = selection['comparisons'][comparison]
    status = {'suite': selection['suite'], 'comparison': comparison, 'selectedOptions': selection['selectedOptions'], 'configurations': selection['configurations'],
              'compatibilityPassed': False, 'timingAccepted': False, 'stage': 'full-tests'}
    status_path = out / 'combined-status.json'
    write_json(status_path, status)
    try:
        verify(out)
        verify_test_sources(out)
        try:
            status['tests'] = full_tests(out, 'combined', selection['configurations'][candidate][1])
        finally:
            verify_test_sources(out)
        status['stage'] = 'full-map-check'
        write_json(status_path, status)
        check(out, java_home / 'bin/java')
        status['mapChecks'] = json.loads((out / 'checks.json').read_text())['configurations']
        status.update(compatibilityPassed=True, stage='timing')
        write_json(status_path, status)
        compare(out, comparison, java_home)
        status.update(timingAccepted=True, stage='complete')
    except Exception as error:
        status['error'] = str(error)
        raise
    finally:
        totals = out / 'combined-test-totals.json'
        if totals.exists():
            status['tests'] = json.loads(totals.read_text())
        try:
            verify(out)
        except Exception as error:
            status.update(timingAccepted=False, error=str(error))
            raise
        finally:
            write_json(status_path, status)


def compact(out, java_home):
    """An incompatible VM/compiler records a failed optional lane, without losing prior results."""
    assert suite_config(out)['suite'] == 'standard', 'Compact action requires the standard suite'
    verify(out)
    status = {'optional': True, 'passed': False, 'readyToTime': False, 'stage': 'full-tests'}
    status_path = out / 'compact-status.json'
    write_json(status_path, status)
    config = json.loads((out / 'run.json').read_text())
    root, frozen = Path(config['repository']), out / 'frozen'
    try:
        # Header-off is now an explicit control, so validate it separately too.
        status['baselineTests'] = full_tests(out, 'compact-baseline', CONFIGURATIONS['class-owned-noncompact'][1])
        status['tests'] = full_tests(out, 'compact', CONFIGURATIONS['class-owned-baseline'][1])
        status['stage'] = 'full-map-check'
        write_json(status_path, status)
        status['baselineMapCheck'] = check_configuration(out, java_home / 'bin/java', 'class-owned-noncompact')
        status['mapCheck'] = check_configuration(out, java_home / 'bin/java', 'class-owned-baseline')
        status['stage'] = 'object-sizes'
        write_json(status_path, status)
        # The published cold probe expects lib/, src/, map/, and a manifest under one root.
        probe = out / 'compact-object-sizes-input'
        shutil.copytree(frozen / 'current', probe)
        shutil.copytree(frozen / 'map', probe / 'map')
        modules = probe / 'map/modules.txt'
        modules.chmod(modules.stat().st_mode | 0o200)
        modules.write_text(''.join(str(probe / 'map' / Path(line).name) + '\n'
                                   for line in (frozen / 'map/modules.txt').read_text().splitlines() if line))
        records = [{'path': str(path.relative_to(probe)), 'sha256': sha(path)}
                   for path in sorted(probe.rglob('*')) if path.is_file()]
        write_json(probe / 'manifest.json', {'files': records})
        command = [sys.executable, frozen / 'helpers/object-sizes.py', probe,
                   out / 'compact-object-sizes', '--java-home', java_home, '--backend', 'bytecode']
        command += ['--jvm-option=' + flag for flag in CONFIGURATIONS['class-owned-baseline'][1]]
        run(out, command, 'compact-object-sizes', 180)
        sizes = (out / 'compact-object-sizes/sizes.out').read_text()
        assert 'VM_OPTION\tUseCompactObjectHeaders\ttrue' in sizes, 'Compact object headers were not active'
        status.update(stage='timing', readyToTime=True)
        write_json(status_path, status)
        compare(out, 'compact-headers', java_home)
        status.update(stage='complete', passed=True)
    except Exception as error:
        status['error'] = str(error)
        print(f'Optional compact-header lane failed at {status["stage"]}: {error}; required results retained.', flush=True)
        if os.environ.get('GITHUB_STEP_SUMMARY'):
            with open(os.environ['GITHUB_STEP_SUMMARY'], 'a') as output:
                output.write(f'\nOptional compact-header experiment failed at `{status["stage"]}`; see compact-status.json and logs. Required comparisons are retained.\n')
    finally:
        write_json(status_path, status)
    # Immutable-input failure is never treated as mere option incompatibility.
    verify(out)


def finish(out):
    verify(out)
    comparisons = {}
    selection = suite_config(out)
    for name in selection['requiredComparisons']:
        path = out / 'comparisons' / name
        validation = json.loads((path / 'validation.json').read_text())
        assert validation['passed'] is True and validation['validatedWindows'] == 45
        comparisons[name] = json.loads((path / 'summary.json').read_text())
    if selection['suite'] == 'standard':
        status = json.loads((out / 'compact-status.json').read_text())
        if status['passed']:
            comparisons['compact-headers'] = json.loads((out / 'comparisons/compact-headers/summary.json').read_text())
        experiment = {'compactHeaders': status}
    else:
        status = json.loads((out / 'combined-status.json').read_text())
        assert status['compatibilityPassed'] is True and status['timingAccepted'] is True
        experiment = {'combined': status}
    summary = {**experiment, 'suite': selection['suite'], 'scope': json.loads((out / 'run.json').read_text())['scope'],
               'immutableInputsUnchanged': True, 'comparisons': comparisons}
    write_json(out / 'summary.json', summary)
    if os.environ.get('GITHUB_STEP_SUMMARY'):
        with open(os.environ['GITHUB_STEP_SUMMARY'], 'a') as output:
            output.write('\n| Comparison | Candidate / baseline | Candidate / native |\n|---|---:|---:|\n')
            for name, result in comparisons.items():
                ratios = result['ratios']
                output.write(f'| {name} | {ratios["candidate/baseline"]:.4f} | {ratios["candidate/native"]:.4f} |\n')
    print(f'All {len(selection["requiredComparisons"])} required comparisons passed, 45 windows each; frozen inputs unchanged.', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('validate', 'freeze', 'check', 'compare', 'compact', 'combined', 'finish'))
    parser.add_argument('out', type=Path)
    parser.add_argument('--baseline-checkout', type=Path)
    parser.add_argument('--comparison', choices=(*COMPARISONS, 'combined', 'all-on'))
    parser.add_argument('--suite', choices=('standard', 'combined', 'all-on'))
    for flag in ('constructor-class', 'unchecked', 'compact-headers'):
        parser.add_argument('--' + flag, choices=('false', 'true'))
    args = parser.parse_args()
    out = args.out.resolve()
    if args.action not in ('validate', 'freeze') and any(getattr(args, key) is not None
            for key in ('suite', 'constructor_class', 'unchecked', 'compact_headers')):
        parser.error('Suite options are accepted only by validate/freeze; later actions use the frozen selection')
    if args.action == 'validate':
        print(json.dumps(selected_suite(args), indent=2))
    elif args.action == 'freeze':
        freeze(out, args.baseline_checkout, selected_suite(args))
    elif args.action == 'finish':
        finish(out)
    else:
        java_home = Path(os.environ['JAVA_HOME']).resolve(strict=True)
        if args.action == 'check':
            check(out, java_home / 'bin/java')
        elif args.action == 'compact':
            compact(out, java_home)
        elif args.action == 'combined':
            combined(out, java_home)
        else:
            assert args.comparison, 'Pass --comparison'
            compare(out, args.comparison, java_home)


if __name__ == '__main__':
    main()
